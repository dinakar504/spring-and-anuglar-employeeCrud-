import { Component, OnInit } from '@angular/core';
import { SEmployeeService } from '../s-employee.service';
import { IEmployee } from '../i-employee';

@Component({
  selector: 'app-fetch-emp-id',
  templateUrl: './fetch-emp-id.component.html',
  styleUrls: ['./fetch-emp-id.component.css']
})
export class FetchEmpIdComponent implements OnInit {

  constructor(private empService: SEmployeeService) { }

  employee:any;

  id:number;

  check:boolean = false;
  check1:boolean = false;

  ngOnInit() {
  }
fetchEmployee(data:any)
{
  this.empService.getEmployeeById(data.id).subscribe((data)=>this.employee=data);
  if(this.employee == null){
    this.check1 = true;
    this.id = data.id;
  }
  else{
    this.check = true;
    this.check1 = false;
  }
}
}
