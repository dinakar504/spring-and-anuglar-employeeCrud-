import { Injectable } from '@angular/core';
import { IEmployee } from './i-employee';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class SEmployeeService {
  
  readonly filePath = "http://localhost:4145/GetAllEmployees"
  baseUrl="http://localhost:4145/DeleteEmployee"
  employees: IEmployee[];

  constructor(private httpService: HttpClient) { }

  addEmployee(addedEmployee: IEmployee):Observable<IEmployee> {
      return this.httpService.post<IEmployee>("http://localhost:4145/EmployeeCreation",addedEmployee, {responseType:'json'})
  }

  getEmployeesInitially(): Observable<IEmployee[]> {
    //this function runs for first time
   return this.httpService.get<IEmployee[]>(this.filePath);
  }
  getEmployeeById(id:number){
    //this function runs for first time
    console.log(id)
   return this.httpService.get("http://localhost:4145/GetEmployee/"+id,{responseType: 'json'});
  }
  setEmployeesInitially(employeesList: IEmployee[]) {
    //set the employees array for future use
    this.employees = employeesList; 
  }
  getSetEmployees() {
    // get the set employees, which runs after first time
    return this.employees; 
  }
  onDeleteEmployee(id: number){
    //deleting the data
    return this.httpService.delete("http://localhost:4145/DeleteEmployee/"+id,{responseType:'text'});
  }
  onUpdateEmployee(employee:any){
  //updating the data
  return this.httpService.put("http://localhost:4145/UpdateEmployee",employee,{responseType:'text'});
  }
}
