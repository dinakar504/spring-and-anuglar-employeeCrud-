import { Component, OnInit } from '@angular/core';
import { IEmployee } from '../i-employee';
import { SEmployeeService } from '../s-employee.service';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {

  message:string;
  constructor(private empService: SEmployeeService) { }
  ngOnInit() {
  }
  onUpdate(updatedEmployee:any){
     //updating the employee
     this.empService.onUpdateEmployee(updatedEmployee).subscribe((data)=>this.message=data);
     console.log(updatedEmployee)
  }
}
